package Day5.Assigment;

public class DownwardHat implements Figure {

    //Instance method
    @Override
    public void getFigure() {
        System.out.print("v");
    }
}
