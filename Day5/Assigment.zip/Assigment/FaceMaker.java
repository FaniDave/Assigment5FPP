package Day5.Assigment;

public class FaceMaker implements Figure {

    //Instance method
    @Override
    public void getFigure() {
        System.out.print(":)");
    }
}
