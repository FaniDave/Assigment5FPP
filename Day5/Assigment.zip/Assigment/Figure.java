package Day5.Assigment;

//Figure Interface
public interface Figure {

    //Abstract method (public abstract)
    void getFigure();
}
