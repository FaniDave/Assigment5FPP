package Day5.Assigment;

//Shape class ( Parent class )
public class Shape {

        //Instance fields
        protected String color;

        //Constructors
        public Shape (String color) {
             this.color = color;
        }

        //Instance methods
        public double calculateArea () {
             return 0.0;
        }
        public double calculatePerimeter () {
             return 0.0;
        }
}
