package Day5.Assigment;

//Square class
public class Square extends Rectangle {

    //Constructor
    public Square(String color, double side) {
        super(color, side, side);
    }
}
