package Day5.Assigment;

public class Vertical implements Figure {

    //Instance method
    @Override
    public void getFigure() {
        System.out.print("||");
    }
}
